package com.example.pokedex

class UserViewHolder {

}
