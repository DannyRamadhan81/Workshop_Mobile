import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.pokedex.data.User
import com.example.pokedex.databinding.ItemRowBinding

class UserAdapter(private val listUser: ArrayList<User>, private val context: Context) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserAdapter.UserViewHolder {
        val itemCardBinding = ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return  UserViewHolder(itemCardBinding)
    }

    override fun onBindViewHolder(holder: UserAdapter.UserViewHolder, position: Int) {
        val user = listUser[position]
        holder.bind(user, this.context)
    }

    override fun getItemCount(): Int = listUser.size

    inner class UserViewHolder(private val binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: User, context: Context) {
            with(binding){
                tvName.text = user.name
                tvType.text = user.type
                tvSpecies.text = user.species
                ivAvatar.setImageResource(user.avatar)
            }
        }

    }
}