package com.example.pokedex.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class User(
    val name: String,
    val type: String,
    val species : String,
    val description : String,
    val hit_point : Int,
    val attack : Int,
    val defense : Int,
    val sp_attack : Int,
    val sp_defense : Int,
    val speed : Int,
    val avatar : Int,
)   : Parcelable
