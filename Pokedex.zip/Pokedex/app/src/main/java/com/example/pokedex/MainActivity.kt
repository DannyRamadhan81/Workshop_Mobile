package com.example.pokedex

import UserAdapter
import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pokedex.data.User
import com.example.pokedex.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private var _activityMainBinding : ActivityMainBinding ?= null
    private val binding get() = _activityMainBinding as ActivityMainBinding

    private var users = arrayListOf<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val adapter = UserAdapter(users, this)
        // setData akan error karena kita belum membuat function tersebut
        setData()
        with(binding.rvUser){
            this.layoutManager = LinearLayoutManager(this@MainActivity)
            this.setHasFixedSize(true)
            this.adapter = adapter
        }
    }

    private fun  setData() {
        val name : Array<String> = resources.getStringArray(R.array.name)
        val type : Array<String> = resources.getStringArray(R.array.type)
        val avatar : TypedArray = resources.obtainTypedArray(R.array.avatar)
        val species : Array<String> = resources.getStringArray(R.array.species)
        val description : Array<String> = resources.getStringArray((R.array.description))
        val hitpoint : IntArray = resources.getIntArray(R.array.hit_point)
        val attack : IntArray = resources.getIntArray(R.array.attack)
        val defense : IntArray = resources.getIntArray(R.array.defense)
        val spattack : IntArray = resources.getIntArray(R.array.sp_attack)
        val spdefense : IntArray = resources.getIntArray(R.array.sp_defense)
        val speed : IntArray = resources.getIntArray(R.array.speed)

        for (i in name.indices){
            val user = User(
                name[i],
                type[i],
                species[i],
                description[i],
                hitpoint[i],
                attack[i],
                defense[i],
                spattack[i],
                spdefense[i],
                speed[i],
                avatar.getResourceId(i, -1)
            )
            users.add(user)
        }

        avatar.recycle()
    }
}
